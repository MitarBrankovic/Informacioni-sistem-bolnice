namespace Model
{
   public enum TipOpreme
   {
        Staticka,
        Dinamicka
   
   }
}