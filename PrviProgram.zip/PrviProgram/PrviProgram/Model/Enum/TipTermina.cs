namespace Model
{
    public enum TipTermina
    {
        Operacija,
        Pregled,
        Kontrola

    }
}