namespace Model
{
    public enum Pol
    {
        Muski,
        Zenski
    }

}