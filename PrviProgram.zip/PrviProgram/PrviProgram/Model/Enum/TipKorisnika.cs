namespace Model
{
    public enum TipKorisnika
    {
        Upravnik,
        Sekretar,
        Pacijent,
        Lekar
    }
}