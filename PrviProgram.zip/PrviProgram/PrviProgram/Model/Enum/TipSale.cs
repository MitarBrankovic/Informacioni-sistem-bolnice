namespace Model
{
    public enum TipSale
    {
        Operaciona,
        SalaZaOdmor,
        Magacin,
        Kancelarija,
        SalaSaKrevetima

    }
}